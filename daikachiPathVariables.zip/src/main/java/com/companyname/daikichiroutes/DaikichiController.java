package com.companyname.daikichiroutes;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
//ctrl + shift + o --> imports all dependencies^ (see above: requestmapping, restcontroller)

@RestController
@RequestMapping("/daikichi")
public class DaikichiController { 
        @RequestMapping("")
        public String index() {
                return "Welcome, weary traveller!";
        }
        
        //using PathVar
        @RequestMapping("m/{travel}/{destination}")
        public String showTravelDestination(@PathVariable("travel") String travel, @PathVariable("destination") String destination) {
        		return "Congratulations! You will soon " + travel + " to " + destination;
        }
        
        //using PathVar
        @RequestMapping("m/lotto/{num}")
        public String lotto(@PathVariable("num") int num) {
        	//if even number is inputted, return following statement,
        	if(num % 2==0) {
        		
        		return "<h1 style='color:blue';> You will take a grand journey in the near future, but beware of tempting offers.";
        	}
        	//else, if odd number is inputted, return following statement,
        	else {
        		return "You have enjoyed the fruits of your labor, now is a great time to enjoy the 'small' things in life.";
        	}
		}
        
        //not using PathVar
        @RequestMapping("/today")
        public String today() {
                return "Today you will attempt something new";
        }
        //***Explicit route calling example below:***
        //@RequestMapping(value = "/today", method = RequestMethod.GET)
        //public String today() {
            //return "Today you will attempt something new";
        //}
        @RequestMapping("/tomorrow")
        public String tomorrow() {
                return "Tomorrow will bring you great fortune";
        }
        
        //Add times visited parameter
	
}
